-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mortgage`
--

DROP TABLE IF EXISTS `mortgage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mortgage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lang` enum('en','si','ta') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `kfd` varchar(255) DEFAULT NULL,
  `btn_1` varchar(255) DEFAULT NULL,
  `btn_2` varchar(255) DEFAULT NULL,
  `btn_3` varchar(255) DEFAULT NULL,
  `hotline` varchar(50) DEFAULT NULL,
  `note` text,
  `charges_tariff` varchar(255) DEFAULT NULL,
  `uploaded_by` varchar(100) NOT NULL DEFAULT 'Backend',
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mortgage`
--

LOCK TABLES `mortgage` WRITE;
/*!40000 ALTER TABLE `mortgage` DISABLE KEYS */;
INSERT INTO `mortgage` VALUES (1,'en','Mortgage','Money can solve all your financial problems. We at Asia Asset invest all our efforts to up your financial lifestyle. This is the fastest way for you to raise funds. Mortgage your asset with us, generate money and in time reclaim your asset. So, stop worrying. Go. Grow. All those problems that are obstacles to you, we have already solved. We promise you an excellent, effective and efficient service. We promise you the fairest rates you can receive because we see you. Afterall, it is our mission to empower people and to transform lives!','/src/media/attachments/customerProtectionFramework/en_key_fact_document_m.pdf','Key Fact Document','Charges & Tariff Sheet','Customer Information Documents','Hotline','Note: These values are indicative and may change time to time*','/src/media/uploads/charges_and_tariff/en_m_cat.png','Backend','2025-02-20 07:59:35'),(2,'si','උකස් ණය','ඒෂියා ඇසට් හි අපි ඔබගේ මූල්‍ය ජීවන රටාව ඉහළ නැංවීම සඳහා අප උත්සහා කරන්නෙමු. ඔබට ගැටළු වන සියල්ල අපි දැනටමත් විසඳා ඇත. අපි ඔබට විශිෂ්ට, ඵලදායී සහ කාර්යක්ෂම සේවාවක් ලබාදීමට පොරොන්දු වන්නෙමු. අපි ඔබට දිය හැකි සාධාරණම ගාස්තු ලබාදීමට පොරොන්දු වන්නෙමු. සියල්ලට පසු, මිනිසුන් සවිබල ගැන්වීම සහ ජීවිත පරිවර්තනය කිරීම අපගේ මෙහෙවරයි!','/src/media/attachments/customerProtectionFramework/si_key_fact_document_m.pdf','ප්‍රධාන තොරතුරු ලේඛනය','ගාස්තු සහ තීරුබදු පත්‍රය','පාරිභෝගික තොරතුරු ලේඛන','ක්ෂණික ඇමතුම්','සැ.යු.: මෙම අගයන් කාලානුකූලව වෙනස් විය හැක.','/src/media/uploads/charges_and_tariff/si_m_cat.png','Backend','2025-02-20 07:59:35'),(3,'ta','தங்கக்கடன்','பொறுப்பு என்பது நமக்கு அனைவருக்கும் வரும் ஒன்று. உங்கள் மகளின் திருமண செலவுகளைப் பற்றி கவலைப்படும் தந்தையாகவும், உங்கள் மகனுக்கு சிறந்த கல்வியை வழங்க முயற்சிக்கும் தாயாகவும், திடீர் அறுவை சிகிச்சைக்கான பணம் தேவைப்படும் துணையாகவும் இருக்கலாம். பயப்படாதீர்கள். எங்கள் தங்க கடன் சேவை உங்கள் தேவைகளை பூர்த்தி செய்ய தயார். எங்கள் கிளைகளில் வருகை தந்து நம்பகத்தன்மை உள்ள நிபுணர்களுடன் பேசுங்கள். தங்கத்தை உங்களுக்கே பாதுகாப்பான இடத்தில் வைத்திருக்க உத்தரவாதம் தருகிறோம்.','/src/media/attachments/customerProtectionFramework/ta_key_fact_document_gl.pdf','முக்கிய தகவல் ஆவணம்','கட்டண மற்றும் விகித பட்டியல்','வாடிக்கையாளர் தகவல் ஆவணங்கள்','துரித எண்','குறிப்பு: குறிப்பு: இந்த மதிப்புகள் அவ்வப்போது மாறும்.','/src/media/uploads/charges_and_tariff/ta_gl_cat.png','Backend','2025-02-20 07:59:35');
/*!40000 ALTER TABLE `mortgage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:37
