-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gold_loan`
--

DROP TABLE IF EXISTS `gold_loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gold_loan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lang` enum('en','si','ta') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `kfd` varchar(255) DEFAULT NULL,
  `btn_1` varchar(255) DEFAULT NULL,
  `btn_2` varchar(255) DEFAULT NULL,
  `btn_3` varchar(255) DEFAULT NULL,
  `btn_4` varchar(255) NOT NULL,
  `hotline` varchar(50) DEFAULT NULL,
  `note` text,
  `charges_tariff` varchar(255) DEFAULT NULL,
  `terms_and_conditions` varchar(255) NOT NULL,
  `uploaded_by` varchar(100) NOT NULL DEFAULT 'Backend',
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang` (`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_loan`
--

LOCK TABLES `gold_loan` WRITE;
/*!40000 ALTER TABLE `gold_loan` DISABLE KEYS */;
INSERT INTO `gold_loan` VALUES (1,'en','Gold Loan','Responsibility is something that comes to all of us. You can be a father, contemplating your daughter’s wedding and the expenses that come with. A mother striving to give her son the best possible education. A spouse in dire need of money for your better half’s sudden surgery. Fear not, ladies and gentlemen. Our Gold Loan Service has got you and your finances covered. Simply walk to any Asia Asset Branch and speak to one of our caring professionals and we’ll take it from there. Here are the guarantees. Instant money. Flexible interest rates, according to your situation. And at the end of it all, your gold has seen a safer space! We are, after all- a fully owned subsidiary of Muthoot Finance, legendary multinational Financial Service Provider with the LARGEST gold loan portfolio around the globe. With Asia Asset Finance PLC’s Gold Loan services, it takes no more than a few minutes for your gold to generate cash. All you need is the gold.','/src/media/attachments/customerProtectionFramework/en_key_fact_document_gl.pdf','Key Fact Document','Charges & Tariff Sheet','Customer Information Documents','Terms & Conditions','Hotline','Note: These values are indicative and may change time to time*','/src/media/uploads/charges_and_tariff/en_gl_cat.png','/src/media/attachments/GL_Terms_and_conditions.pdf','admin1','2025-08-04 03:28:13'),(2,'si','රන් ණය','අපි ලොව පුරා විශාලතම රන් ණය සේවා සපයන බහුජාතික මූල්‍ය සේවා සපයන්නෙකු වන මුතූට් ෆිනෑන්ස් හි පූර්ණ අනුබද්ධිත ආයතනයක් වෙමු. අපගේ රන් ණය සේවා සමඟින්, ඔබේ රත්‍රන් සඳහා මුදල් කරගැනීමට මිනිත්තු කිහිපයකට වඩා ගත නොවේ. ඔබට අවශ්‍ය වන්නේ රත්‍රන් පමණි.','/src/media/attachments/customerProtectionFramework/si_key_fact_document_gl.pdf','ප්‍රධාන තොරතුරු ලේඛනය','ගාස්තු සහ තීරුබදු පත්‍රය','පාරිභෝගික තොරතුරු ලේඛන','කොන්දේසි සහ නියාමන','ක්ෂණික ඇමතුම්','සැ.යු.: මෙම අගයන් කාලානුකූලව වෙනස් විය හැක.','/src/media/uploads/charges_and_tariff/si_gl_cat.png','/src/media/attachments/GL_Terms_and_conditions.pdf','admin1','2025-02-25 06:31:38'),(3,'ta','தங்கக்கடன்','பொறுப்பு என்பது நமக்கு அனைவருக்கும் வரும் ஒன்று. உங்கள் மகளின் திருமண செலவுகளைப் பற்றி கவலைப்படும் தந்தையாகவும், உங்கள் மகனுக்கு சிறந்த கல்வியை வழங்க முயற்சிக்கும் தாயாகவும், திடீர் அறுவை சிகிச்சைக்கான பணம் தேவைப்படும் துணையாகவும் இருக்கலாம். பயப்படாதீர்கள். எங்கள் தங்க கடன் சேவை உங்கள் தேவைகளை பூர்த்தி செய்ய தயார். எங்கள் கிளைகளில் வருகை தந்து நம்பகத்தன்மை உள்ள நிபுணர்களுடன் பேசுங்கள். தங்கத்தை உங்களுக்கே பாதுகாப்பான இடத்தில் வைத்திருக்க உத்தரவாதம் தருகிறோம்.','/src/media/attachments/customerProtectionFramework/ta_key_fact_document_gl.pdf','முக்கிய தகவல் ஆவணம்','கட்டண மற்றும் விகித பட்டியல்','வாடிக்கையாளர் தகவல் ஆவணங்கள்','விதிமுறைகள் மற்றும் நிபந்தனைகள்','துரித எண்','குறிப்பு: குறிப்பு: இந்த மதிப்புகள் அவ்வப்போது மாறும்.','/src/media/uploads/charges_and_tariff/ta_gl_cat.png','/src/media/attachments/GL_Terms_and_conditions.pdf','Backend','2025-02-20 07:57:58');
/*!40000 ALTER TABLE `gold_loan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:37
