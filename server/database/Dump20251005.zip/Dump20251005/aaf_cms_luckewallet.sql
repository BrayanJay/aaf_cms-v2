-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `luckewallet`
--

DROP TABLE IF EXISTS `luckewallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `luckewallet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lang` enum('en','si','ta') NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `kfd` varchar(255) DEFAULT NULL,
  `btn_1` varchar(255) DEFAULT NULL,
  `btn_2` varchar(255) DEFAULT NULL,
  `hotline` varchar(50) DEFAULT NULL,
  `note` text,
  `uploaded_by` varchar(100) NOT NULL DEFAULT 'Backend',
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `luckewallet`
--

LOCK TABLES `luckewallet` WRITE;
/*!40000 ALTER TABLE `luckewallet` DISABLE KEYS */;
INSERT INTO `luckewallet` VALUES (1,'en','Luckewallet','Access Your Wealth From Anywhere','Luckewallet has firmly established itself as the leading payment platform in Sri Lanka, renowned for its high transaction volume and customer base. Luckewallet offers a wide range of financial services, including digital savings accounts, digital fixed deposits, and Gold Loan interest payments. Additionally, users can pay utility bills and accept credit card payments without needing to visit a physical branch. The platform is designed to seamlessly connect customers and merchants, providing a secure and integrated experience. An extension of our e-savings account offering is its highly competitive interest rate, which stands out in the market. The e-savings account provides users with the ability to earn interest in their savings while enjoying the flexibility and convenience of managing their funds digitally. Customers can open and manage their digital savings accounts directly through the app, with the added benefit of earning interest that is typically higher than traditional savings accounts. This feature allows users to grow their savings effortlessly, with the ease of accessing their funds and tracking their account activity at any time. More than just a payment platform, Luckewallet is envisioned as a comprehensive ecosystem, with the company acting as a merchant-acquiring partner. Recognized internationally for its advanced software architecture, the app is continually improved to ensure a smooth and efficient user experience. Key features include easy customer onboarding, self-registration, and a variety of services such as mobile recharges and direct transactions with other bank accounts. With the e-savings account and its competitive interest rate, Luckewallet is offering more than just digital transactions — it’s helping users build their financial future.','/src/media/attachments/customerProtectionFramework/en_key_fact_document_s.pdf','Key Fact Document','Customer Information Documents','Hotline','Note: These are values indicative and may change time to time*','Backend','2025-02-20 07:58:57'),(2,'si','Luckewallet','ඕනෑම තැනක සිට ඔබේ වත්කම් වෙත ප්‍රවේශ වන්න','Luckewallet ශ්‍රී ලංකාවේ ප්‍රමුඛතම ගෙවීම් වේදිකාව ලෙස ස්ථිරව තහවුරු වී ඇති අතර, එහි ඉහළ ගනුදෙනු ප්‍රමානය සහ පාරිභෝගික පදනම සඳහා ද ප්‍රචලිත වේ. ලකීවොලට් ඩිජිටල් ඉතුරුම් ගිණුම්, ඩිජිටල් ස්ථාවර තැන්පතු සහ රන් ණය පොලී ගෙවීම් ඇතුළු පුළුල් පරාසයක මූල්‍ය සේවා සපයයි. අමතරව, පරිශීලකයින්ට භෞතික ශාඛාවකට නොපැමිණ පාරිභෝගික සේවා බිල්පත් සහ ක්‍රෙඩිට් කාඩ් ගෙවීම් ද මේ තුලින් සිදුකල හැක. එමෙන්ම මෙය සැලසුම් කර ඇත්තේ පාරිභෝගිකයින් සහ වෙළෙන්දන් බාධාවකින් තොරව සම්බන්ධ කිරීමට, මෙන්ම ආරක්ෂිත සහ ඒකාබද්ධ අත්දැකීමක් ලබා දීම සඳහා ය. ඉතා තරඟකාරී පොලී අනුපාතය අපගේ ඩිජිටල් ඉතුරුම් ගිණුම් සේවාව සඳහා ඇති විශේෂාංගයක් වන අතර එය වෙළඳපොල තුල කැපී පෙනේ. විද්‍යුත් ඉතුරුම් ගිණුම මඟින් පරිශීලකයින්ට ඔවුන්ගේ අරමුදල් ඩිජිටල් ලෙස කළමනාකරණය කිරීමේ නම්‍යශීලීභාවය සහ පහසුවෙන් ඔවුන්ගේ ඉතුරුම් සඳහා පොලී උපයා ගැනීමේ හැකියාව ලබා දේ. සාමාන්‍යයෙන් සාම්ප්‍රදායික ඉතුරුම් ගිණුම්වලට වඩා වැඩි පොලී ඉපැයීමේ අමතර ප්‍රතිලාභයක් සමඟින් පාරිභෝගිකයින්ට ඔවුන්ගේ ඩිජිටල් ඉතුරුම් ගිණුම්,  යෙදුම හරහා සෘජුවම විවෘත කර කළමනාකරණය කළ හැකිය. මෙම විශේෂාංගය පරිශීලකයින්ට ඔවුන්ගේ අරමුදල් වෙත ප්‍රවේශ වීමේ පහසුව  මෙන්ම ඕනෑම වේලාවක ඔවුන්ගේ ගිණුම් ක්‍රියාකාරකම් නිරීක්ෂණය කිරීමේ පහසුව සමඟින් ඉතුරුම් පහසුවෙන් වර්ධනය කර ගැනීමට ඉඩ සලසයි. Luckewallet සාමාන්‍ය ගෙවීම් වේදිකාවක් ලෙසට සීමා නොවී, සම්පූර්ණ පද්ධතියක් ලෙස ස්ථාපිත වෙමින්, විශ්වාසදායී වෙළඳ-ලබාගැනීමේ හවුල්කරු ලෙස සේවය කරයි. ඉහළ මට්ටමේ මෘදුකාංග ව්‍යුහ සම්පාදනය සඳහා ජාත්‍යන්තර වශයෙන් ප්‍රසිද්ධ මෙම යෙදුම, මෘදු සහ කාර්යක්ෂම පාරිභෝගික අත්දැකීමක් ලබා දීමට නිරන්තරයෙන් වැඩිදියුණු කරයි. මූලික විශේෂාංග සඳහා පහසුවෙන් පාරිභෝගිකයින් එක් කිරීම, ස්වයං ලියාපදිංචි කිරීම, මෙන්ම ජංගම ඇමතුම් රිචාජ් සහ අනෙකුත් බැංකු ගිණුම් සමඟ සෘජු ගනුදෙනු වැනි විවිධ සේවාවන් ඇතුළත් වේ. ඩිජිටල් ඉතුරුම් ගිණුම සහ එහි තරඟකාරී පොලී අනුපාතය සමඟ, Luckewallet ඩිජිටල් ගනුදෙනු පමණක් නොව, පරිශීලකයින්ට ඔවුන්ගේ මූල්‍ය අනාගතය ගොඩනැගීමට උපකාරී වේ.','/src/media/attachments/customerProtectionFramework/si_key_fact_document_s.pdf','ප්‍රධාන තොරතුරු ලේඛනය','පාරිභෝගික තොරතුරු ලේඛන','ක්ෂණික ඇමතුම්','සැ.යු.: මෙම අගයන් කාලානුකූලව වෙනස් විය හැක.','Backend','2025-02-20 07:58:57'),(3,'ta','Luckewallet','உங்கள் செல்வத்தை எங்கிருந்தாலும் அணுகுங்கள்','Luckewallet  இலங்கையில் முன்னணி பணம் பரிவர்த்தனை தளமாக தன்னை உறுதியாக நிலைநிறுத்தியுள்ளது. இது அதிகமான பரிவர்த்தனை அளவுக்காகவும், பரந்த வாடிக்கையாளர் அடிப்படைக்காகவும் பிரபலமானது. Luckewallet பலவகையான நிதி சேவைகளை வழங்குகிறது, அவற்றில் டிஜிட்டல் சேமிப்பு கணக்குகள், டிஜிட்டல் நிலையான வைப்புகள், மற்றும் தங்கக் கடன் வட்டி செலுத்தல் அடங்கும். பயனர்கள் தங்கள் பயன்பாட்டு மின்சாரக் கட்டணங்களைச் செலுத்தலாம் மற்றும் கிரெடிட் கார்டு பணப் பரிவர்த்தனைகளை எந்த ஒரு கிளையையும் சென்று தேவை இல்லாமல் ஏற்றுக்கொள்ளலாம். இந்த தளம், வாடிக்கையாளர்களையும் வியாபாரிகளையும் முழுமையாக இணைக்கும் வகையில் வடிவமைக்கப்பட்டுள்ளது, பாதுகாப்பான மற்றும் ஒருங்கிணைந்த அனுபவத்தை வழங்குகிறது. எங்கள் E-சேமிப்பு கணக்கின் நீட்சியான அம்சம் இதன் மிகப் போட்டித்தன்மை கொண்ட வட்டி விகிதமாகும், இது சந்தையில் தனித்துவமானதாக இருக்கிறது. E-சேமிப்பு கணக்கு பயனர்களுக்கு தங்கள் சேமிப்புகளில் வட்டி சம்பாதிக்கும் வசதியையும், நிதிகளை டிஜிட்டல் முறையில் நிர்வகிக்கும் சுதந்திரத்தையும் வழங்குகிறது. வாடிக்கையாளர்கள் தங்கள் டிஜிட்டல் சேமிப்பு கணக்குகளை நேரடியாக செயலியின் மூலம் திறக்கவும் நிர்வகிக்கவும் முடியும், மேலும் வழக்கமான சேமிப்பு கணக்குகளைவிட உயர்ந்த வட்டி சம்பாதிக்கவும் கூடுதல் நன்மை உள்ளது. இந்த அம்சம் பயனர்களுக்கு தங்கள் சேமிப்புகளை எளிதாக வளர்க்கும் வாய்ப்பை வழங்குகிறது, எப்போது வேண்டுமானாலும் தங்கள் நிதிகளை அணுகவும் கணக்கு நடவடிக்கைகளை கண்காணிக்கவும் அனுகுமுறையுடன். Luckewallet  சாதாரணமாக ஒரு கட்டண தளம் அல்ல, முழுமையான சுற்றுச்சூழல் அமைப்பாக காட்சியளிக்கப்படுகிறது, நிறுவனமானது வியாபாரியர்களை பெற்றுக் கொள்ளும் கூட்டாளியாக செயல்படுகிறது. மேம்பட்ட மென்பொருள் கட்டமைப்பிற்காக சர்வதேச அளவில் பாராட்டப்பட்ட இந்த செயலி, பயனர்களுக்கு மெலிதான மற்றும் செயல்திறனான அனுபவத்தை உறுதிப்படுத்த தொடர்ந்து மேம்படுத்தப்படுகிறது. முக்கிய அம்சங்களில் எளிய வாடிக்கையாளர் சேர்க்கை, சுய பதிவேற்றம், மற்றும் மொபைல் ரீசார்ஜ்கள் மற்றும் பிற வங்கிக் கணக்குகளுடன் நேரடி பரிவர்த்தனைகளைச் செய்யும் பல்வேறு சேவைகள் அடங்கும். E-சேமிப்பு கணக்கு மற்றும் அதனுடைய போட்டித்தன்மை வாய்ந்த வட்டி விகிதத்துடன், Luckewallet  டிஜிட்டல் பரிவர்த்தனைகளுக்கு மேல் செல்லும் ஒரு பயணத்தை வழங்குகிறது — இது பாவனையாளர்களுக்கு தங்கள் நிதி எதிர்காலத்தை உருவாக்க உதவுகிறது.\r\n      ','/src/media/attachments/customerProtectionFramework/ta_key_fact_document_s.pdf','முக்கிய தகவல் ஆவணம்','வாடிக்கையாளர் தகவல் ஆவணங்கள்','துரித எண்','குறிப்பு: இந்த மதிப்புகள் சுட்டுரைச் செய்யும் பொருட்டு மட்டுமே வழங்கப்பட்டுள்ளன மற்றும் அவை காலத்தின்படி மாறக்கூடும்.','Backend','2025-02-20 07:58:57');
/*!40000 ALTER TABLE `luckewallet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:35
