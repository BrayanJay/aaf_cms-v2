-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forex`
--

DROP TABLE IF EXISTS `forex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lang` enum('en','si','ta') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `btn_1` varchar(255) DEFAULT NULL,
  `hotline` varchar(50) DEFAULT NULL,
  `note` text,
  `our_partners_title` varchar(255) DEFAULT NULL,
  `uploaded_by` varchar(100) NOT NULL DEFAULT 'Backend',
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forex`
--

LOCK TABLES `forex` WRITE;
/*!40000 ALTER TABLE `forex` DISABLE KEYS */;
INSERT INTO `forex` VALUES (1,'en','Forex','At Asia Asset Finance you can get your Foreign Exchange Transactions done in a flash! Just walk over to one of our counters with your cash and let the trading happen. So, here is how Forex works. In the simplest form of describing it, it is the act of selling one currency to buy another. These are always quoted in pairs- that is, how much one unit of base(bought) currency is in terms of quote (sold) currency. With our professional advice, and constant on our toes approach, watch your wealth multiply.','Customer Information Documents','Hotline','Note: These values are indicative and may change time to time*','Our Partners','Backend','2025-02-20 07:57:22'),(2,'si','විදේශ විනිමය','Asia Asset Finance හි ඔබට ඔබගේ විදේශ විනිමය ගනුදෙනු ක්ෂණිකව සිදු කර ගත හැක. ඔබගේ මුදල් සමඟ අපගේ කවුන්ටරයන්ගෙන් එකකට ගොස් හුවමාරුව  සිදුවන අයුරු බලාසිටින්න.  Forex  විස්තර කිරීමේ සරලම ආකාරය ලෙස, එක්  මුදල් වර්ගයක් මිලදී ගැනීම සඳහා තවත් මුදල් ඒකකයක් විකිණීම විස්තර කලහැකිය. මෙය සෑම විටම යුගල වශයෙන් උපුටා දක්වා ඇත- එනම්, පාදක (මිලදී ගත්) මුදල් ඒකකයක් උද්ධෘත (විකුණුම්) මුදල් අනුව කොපමණ වේද ලෙසයි. අපගේ වෘත්තීය උපදෙස් සමඟින් ඔබේ ධනය වැඩි වන අයුරු බලාගැනීමට ඔබට අවස්ථාව ලැබේ.','පාරිභෝගික තොරතුරු ලේඛන','ක්ෂණික ඇමතුම්','සැ.යු.: මෙම අගයන් කාලානුකූලව වෙනස් විය හැක.','අපගේ හවුල්කරුවන්','Backend','2025-02-20 07:57:22'),(3,'ta','வெளிநாட்டு நாணய மாற்று','ஏசியா எசட் பைனான்ஸ் உங்கள் வெளிநாட்டு நாணய மாற்றங்களை   ஒரே நேரத்தில் செய்துவிடலாம். அதை விவரிக்கும் எளிய வடிவத்தில், இது ஒரு நாணயத்தை விற்று மற்றொரு நாணயத்தை வாங்குவதாகும். இவை எப்போதும் ஜோடிகளாகவே மேற்கோள் காட்டப்படும்- அதாவது, அடிப்படை (வாங்கிய) நாணயத்தின் ஒரு யூனிட், மேற்கோள் (விற்ற) நாணயத்தின் அடிப்படையில் எவ்வளவு. எங்களுடைய தொழில்முறை ஆலோசனையுடன், எங்கள் அணுகுமுறையுடன், உங்கள் செல்வம் பெருகுவதைப் பாருங்கள்.','வாடிக்கையாளர் தகவல் ஆவணங்கள்','துரித எண்','குறிப்பு: இந்த மதிப்புகள் அவ்வப்போது மாறும்.','எங்கள் துணை முகவர்கள்','Backend','2025-02-20 07:57:22');
/*!40000 ALTER TABLE `forex` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:36
