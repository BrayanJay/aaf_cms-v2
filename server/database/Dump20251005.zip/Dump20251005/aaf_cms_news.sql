-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(500) NOT NULL,
  `summary` varchar(500) DEFAULT NULL,
  `content` longtext NOT NULL,
  `author` varchar(255) NOT NULL,
  `category` enum('NEWS','EVENT','ANNOUNCEMENT','PRESS RELEASE','BRANCH OPENNING','ACHIEVEMENT') NOT NULL DEFAULT 'NEWS',
  `status` enum('DRAFT','PUBLISHED','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
  `featured_image` varchar(500) DEFAULT NULL,
  `tags` longtext,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(500) DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_news_status` (`status`),
  KEY `idx_news_category` (`category`),
  KEY `idx_news_published_at` (`published_at`),
  KEY `idx_news_slug` (`slug`),
  KEY `idx_news_created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `news_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `news_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Asia Asset Finance PLC Delivers Powerful Q1, Eyes LKR 50Bn Assets Target with Rapid Growth','asia-asset-finance-2025-q1-growth','Asia Asset Finance PLC reports exceptional Q1 2025 results with 123% PBT growth, reaching LKR 41.8 billion in assets and targeting the LKR 50 billion milestone through strategic expansion and four new branch openings.','<div class=\"article-content\">\n        <p>Colombo, 30 June 2025 – Asia Asset Finance PLC (AAF), one of Sri Lanka’s most trusted and fastest-growing non-banking financial institutions, has reported a Profit Before Tax (PBT) of LKR 294.8 million – reflecting a 123% year-on-year growth compared to LKR 132.2 million in Q1 2024 – and a Profit After Tax (PAT) of LKR 181 million, representing a 57% year-on-year increase from LKR 115.8 million in Q1 2024, for the first quarter ended 30 June 2025. This robust performance underscores the company’s resilience and its ability to sustain growth in a competitive financial services landscape.</p>\n        <p>The significant growth in PBT demonstrates AAF’s ability to generate strong pre-tax earnings through revenue expansion and operational efficiency. Meanwhile, the healthy 57% rise in PAT reflects not only stronger operating performance but also effective management of operational costs and financing costs.</p>\n        <p>The company’s asset base has now reached an impressive LKR 41.8 billion, and with strong momentum across all its business segments, AAF is firmly on course to achieve its next significant milestone – the LKR 50 billion mark – in the near future. This milestone reflects not only financial strength but also the company’s strategic focus on expansion, innovation, and inclusivity in its services.</p>\n        <p>Asia Asset Finance’s footprint continued to grow during the first quarter, with the opening of four new branches, strengthening its presence in key regions and ensuring greater accessibility for customers. This expansion is a clear demonstration of AAF’s commitment to financial inclusion, enabling individuals, families, and small businesses to access much-needed credit and investment products closer to where they live and work.</p>\n        <h6>Reflecting on the strong start to the year, Rajiv Gunawardana, Chief Executive Officer of Asia Asset Finance PLC, said:</h6>\n        <p>“Our Q1 results are not just about the numbers – they reflect our strategy in action. We are expanding our reach, strengthening our portfolio, and positioning Asia Asset Finance to become a valued financial service provider for the people of Sri Lanka. As we look ahead, our focus remains clear: to continue delivering value to our customers and shareholders while contributing to Sri Lanka’s economic growth.”</p>\n        <p>Backed by the global strength of its parent company, Muthoot Finance, the world’s largest gold financing company, Asia Asset Finance benefits from deep international expertise while remaining firmly rooted in Sri Lanka’s financial sector. With an A+ Fitch Rating, a 55-year legacy of trust, and an expanding network of 105 branches reaching into rural areas, AAF continues to build a strong foundation for the future.</p>\n        <p>The first quarter of 2025 has set the tone for another year of growth and transformation for Asia Asset Finance. With a strong financial performance, ambitious expansion plans, and a clear trajectory towards the LKR 50 billion asset milestone, the company is redefining its role in the financial services industry and solidifying its place as one of Sri Lanka’s most dynamic and forward-looking institutions.</p>\n    </div>','Branding & Marketing Team','NEWS','PUBLISHED','/news/asia-asset-finance-2025-q1-growth','Growth, Financial Performance, Expansion',NULL,NULL,'2025-09-09 03:55:26','2025-09-09 03:55:26','2025-09-09 06:22:37',1,NULL);
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:35
