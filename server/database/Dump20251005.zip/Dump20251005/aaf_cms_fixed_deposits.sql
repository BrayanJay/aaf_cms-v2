-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fixed_deposits`
--

DROP TABLE IF EXISTS `fixed_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fixed_deposits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lang` enum('en','si','ta') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `kfd` varchar(255) DEFAULT NULL,
  `btn_1` varchar(255) DEFAULT NULL,
  `btn_2` varchar(255) DEFAULT NULL,
  `btn_3` varchar(255) DEFAULT NULL,
  `btn_4` varchar(255) DEFAULT NULL,
  `collectionAccountsImg` varchar(255) DEFAULT NULL,
  `hotline` varchar(50) DEFAULT NULL,
  `note` text,
  `fdRatesImg` varchar(255) DEFAULT NULL,
  `uploaded_by` varchar(100) NOT NULL DEFAULT 'Backend',
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_deposits`
--

LOCK TABLES `fixed_deposits` WRITE;
/*!40000 ALTER TABLE `fixed_deposits` DISABLE KEYS */;
INSERT INTO `fixed_deposits` VALUES (1,'en','Fixed Deposits','It is never a bad time to start saving and it is never a bad idea to start saving with us. With a history spanning over 50 years, Asia Asset Finance PLC has become a time-tested investment partner as a finance company registered with the Central Bank of Sri Lanka. We ensure the security of your wealth, whilst offering deposit rates which are designed to ensure consistently competitive returns. Sri Lanka has faced multiple economic crises and in spite of that Asia Asset has always delivered. Our services include door-to-door service with a friendly and personalized team of professionals to cater to your individual requirements.','/src/media/attachments/customerProtectionFramework/en_key_fact_document_fd.pdf','Key Fact Document','FD Rates','Customer Information Documents','Collection Bank Accounts','/src/media/uploads/fd_collection_accounts.webp','Hotline','Note: These values are indicative and may change time to time*','/src/media/uploads/en_fd_rates.webp','admin1','2025-03-05 04:13:00'),(2,'si','ස්ථාවර තැන්පතු','ඉතිරි කිරීම ආරම්භ කිරීමට කිසිවිටෙක නරක කාලයක් නොවන අතර අප සමඟ ඉතිරි කිරීම ආරම්භ කිරීම කිසිදු අයුරකින් නරක අදහසක් නොවේ. වසර 50කට අධික ඉතිහාසයක් ඇති Asia Asset Finance PLC වන අප ශ්‍රී ලංකා මහ බැංකුවේ ලියාපදිංචි මූල්‍ය සමාගමක් ලෙස ආයෝජන හවුල්කරුවෙකු බවට පත්ව ඇත. තරඟකාරී ස්ථාවර ප්‍රතිලාභ සහතික කිරීම සඳහා නිර්මාණය කර ඇති තැන්පතු අනුපාත ඔබ වෙත පිරිනමමින් අපි ඔබේ වත්කම් හි ආරක්ෂාව සහතික කරමු. ශ්‍රී ලංකාව විවිධ ආර්ථික අර්බුද වලට මුහුණ දී ඇති අතර, එසේ තිබියදීත් ඒෂියා  ඇසට් ආයතනය සෑම විටම ඔබට සිය සේවාව ලබා දී ඇත.','/src/media/attachments/customerProtectionFramework/si_key_fact_document_fd.pdf','ප්‍රධාන තොරතුරු ලේඛනය','පොලී අනුපාත','පාරිභෝගික තොරතුරු ලේඛන','එකතු කිරීමේ බැංකු ගිණුම්','/src/media/uploads/fd_collection_accounts.webp','ක්ෂණික ඇමතුම්','සැ.යු.: මෙම අගයන් කාලානුකූලව වෙනස් විය හැක.','/src/media/uploads/si_fd_rates.webp','Backend','2025-02-20 07:53:26'),(3,'ta','நிலையான வைப்புக்கள்','சேமிக்கத் தொடங்குவதற்கு இது ஒரு மோசமான நேரமல்ல, எங்களிடம் சேமிக்கத் தொடங்குவது மோசமான யோசனையல்ல. 50 ஆண்டுகளுக்கும் மேலான வரலாற்றைக் கொண்டு, ஏசியா எசட் பைனான்ஸ் பீ எல் சீ ஆனது, இலங்கை மத்திய வங்கியில் பதிவுசெய்யப்பட்ட நிதி நிறுவனமாக காலத்தால் சோதிக்கப்பட்ட முதலீட்டு பங்காளியாக மாறியுள்ளது. உங்கள் செல்வத்தின் பாதுகாப்பை நாங்கள் உறுதிசெய்கிறோம், அதேசமயம் டெபாசிட் விகிதங்களை வழங்குகிறோம். இலங்கையானது பல பொருளாதார நெருக்கடிகளை எதிர்கொண்டுள்ளது. இருந்த போதிலும் ஆசிய சொத்துக்கள் எப்போதும் வழங்கப்பட்டுள்ளன. உங்கள் தனிப்பட்ட தேவைகளைப் பூர்த்தி செய்வதற்காக நட்பு மற்றும் தனிப்பயனாக்கப்பட்ட நிபுணர்களின் குழுவுடன் வீடு வீடாகச் செல்லும் சேவை எங்கள் சேவைகளில் அடங்கும்.','/src/media/attachments/customerProtectionFramework/ta_key_fact_document_fd.pdf','முக்கிய தகவல் ஆவணம்','வட்டி விகிதம்','வாடிக்கையாளர் தகவல் ஆவணங்கள்','Collection Bank Accounts','/src/media/uploads/fd_collection_accounts.webp','துரித எண்','குறிப்பு: குறிப்பு: இந்த மதிப்புகள் அவ்வப்போது மாறும்.','/src/media/uploads/ta_fd_rates.webp','admin1','2025-03-20 09:30:06');
/*!40000 ALTER TABLE `fixed_deposits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:36
