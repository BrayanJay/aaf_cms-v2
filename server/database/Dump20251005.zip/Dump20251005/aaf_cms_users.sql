-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(255) DEFAULT NULL,
  `role` enum('admin','editor','contributor','viewer') NOT NULL DEFAULT 'viewer',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_last_login` (`last_login`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'cms-admin','$2b$10$/SE3CKF1aZCVj0YEe8VR4OuhgTKUYgLoV.O.zOYYYfqXkQfIh/ZFe','2025-02-17 06:23:19','4721cc89c9a38ac1c7cc9ba2edf876ed7a3f624b8b21be0aadc85a43abf6d25ef8f03cc17b96a4417dc31156b449c065fe31bbb0bcf833eeb96fd3b99437477c','admin','2025-09-24 08:04:09','2025-09-24 08:04:09'),(6,'marketing-dept','$2b$10$/PYMN4uHN1s66Rzc6iyoe.szByythrTH.hF/S93dQe2.bo3z/peeO','2025-08-14 10:16:11','19ba75833057f64e7a352c7f862c3000cac1a47017c17bd2bac860ed6b5f23f1823a26393512ee34eb0309c223343473e5f7ffd32dc34d2eedafcc5e7bc60bed','editor','2025-08-25 02:32:01','2025-08-25 02:32:01'),(7,'communication-dept','$2b$10$cD47J/Ap/VRoOI1VRull2u3j8W7eYN0lSeXk39DmzUsqhuXHw/AEy','2025-08-25 02:33:29','64e4d5644a841741493123ba9283233ad251a0ce381c5cc6deb51bcefd5bf8afac0d961d84897bed2769d8c07ab32c36275d3b4863fccbd73e89b41c9b428688','contributor','2025-08-25 02:34:29','2025-08-25 02:34:29');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:36
