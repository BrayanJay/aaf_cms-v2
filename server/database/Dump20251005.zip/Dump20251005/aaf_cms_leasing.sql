-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aaf_cms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `leasing`
--

DROP TABLE IF EXISTS `leasing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leasing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lang` enum('en','si','ta') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `kfd` varchar(255) DEFAULT NULL,
  `btn_1` varchar(255) DEFAULT NULL,
  `btn_2` varchar(255) DEFAULT NULL,
  `btn_3` varchar(255) DEFAULT NULL,
  `hotline` varchar(50) DEFAULT NULL,
  `note` text,
  `charges_tariff` varchar(255) DEFAULT NULL,
  `uploaded_by` varchar(100) NOT NULL DEFAULT 'Backend',
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leasing`
--

LOCK TABLES `leasing` WRITE;
/*!40000 ALTER TABLE `leasing` DISABLE KEYS */;
INSERT INTO `leasing` VALUES (1,'en','Leasing','Don’t let anyone tell you that you should not drive your dream vehicle NOW! Any vehicle you could have possibly wanted to drive or ride is just one visit to your nearest Asia Asset Branch away. Own it. Drive it. And all the time in the world to pay for it. In this deal, you WIN! When you apply for a lease from us our trained professionals will provide you with; The finest interest rates in the market, Doorstep Service, Minimum Documentation, Zero Hassle, Flexible Repayment Terms & etc. So, lease with ease with us and drive your dream!','/src/media/attachments/customerProtectionFramework/en_key_fact_document_l.pdf','Key Fact Document','Charges & Tariff Sheet','Customer Information Documents','Hotline','Note: These values are indicative and may change time to time*','/src/media/uploads/charges_and_tariff/en_m_cat.png','Backend','2025-02-20 07:58:25'),(2,'si','ලීසිං ණය','ඔබ ඔබේ සිහින වාහනය ධාවනය නොකළ යුතු බව කිසිවෙකුට පැවසීමට ඉඩ නොදෙන්න! ඔබට පැදවීමට අවශ්‍ය ඕනෑම වාහනයක් මිලදී ගැනීමට අවශ්‍ය සහය ඔබේ ළඟම ඇති ඒෂියා ඇසට් ශාඛාවක් වෙත ගොස් ලබාගැනීමට දැන් ඔබට අවස්ථාව ඇත. ඔබ අපගෙන් මේ සඳහා අයදුම් කරන විට අපගේ පුහුණු වෘත්තිකයන් ඔබට වෙළඳපොලේ ඇති හොඳම පොලී අනුපාත, අවම ලේඛන, කරදරයකින් තොර, නම්‍යශීලී ආපසු ගෙවීමේ නියමයන් ඇතුලු සේවා රැසක් ඔබගේ නිවසටම පැමිණ ලබාදේ. එබැවින්, අපත් සමඟ පහසුවෙන් ඔබේ සිහින වාහනය ලබාගන්න!','/src/media/attachments/customerProtectionFramework/si_key_fact_document_l.pdf','ප්‍රධාන තොරතුරු ලේඛනය','ගාස්තු සහ තීරුබදු පත්‍රය','පාරිභෝගික තොරතුරු ලේඛන','ක්ෂණික ඇමතුම්','සැ.යු.: මෙම අගයන් කාලානුකූලව වෙනස් විය හැක.','/src/media/uploads/charges_and_tariff/si_l_cat.png','Backend','2025-02-20 07:58:25'),(3,'ta','குத்தகை','உங்கள் கனவு வாகனத்தை நீங்கள் இப்போது ஓட்டக்கூடாது என்று யாரும் சொல்ல வேண்டாம்! நீங்கள் ஓட் விரும்பும் எந்தவொரு வாகனமும், உங்கள் அருகில் உள்ள ஆசிய அசெட் கிளைக்கு ஒரு முறை சென்று வந்தால் போதும். சொந்தமாக. ஓட்டுங்கள். மேலும் உலகில் உள்ள எல்லா நேரமும் அதற்கு பணம் செலுத்த வேண்டும். இந்த ஒப்பந்தத்தில், நீங்கள் வெற்றி பெறுவீர்கள்! எங்களிடமிருந்து நீங்கள் குத்தகைக்கு விண்ணப்பிக்கும்போது, ​​எங்கள் பயிற்சி பெற்ற வல்லுநர்கள் உங்களுக்கு வழங்குவார்கள்; சந்தையில் சிறந்த வட்டி விகிதங்கள், வீட்டு வாசல் சேவை, குறைந்தபட்ச ஆவணங்கள், நெகிழ்வான திருப்பிச் செலுத்தும் விதிமுறைகள் மற்றும் பல. எனவே, எங்களுடன் எளிதாக குத்தகைக்கு எடுத்து உங்கள் கனவை இயக்குங்கள்!','/src/media/attachments/customerProtectionFramework/ta_key_fact_document_l.pdf','முக்கிய தகவல் ஆவணம்','கட்டண மற்றும் விகித பட்டியல்','வாடிக்கையாளர் தகவல் ஆவணங்கள்','துரித எண்','குறிப்பு: குறிப்பு: இந்த மதிப்புகள் அவ்வப்போது மாறும்.','/src/media/uploads/charges_and_tariff/ta_l_cat.png','Backend','2025-02-20 07:58:25');
/*!40000 ALTER TABLE `leasing` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 22:31:35
